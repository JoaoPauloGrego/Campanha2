const express = require('express');
const session = require('express-session');
const db = require('./db/database');
const app = express();
const port = 3000;

// Configurações
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Sessões para login
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true
}));

// Rotas
app.get('/', (req, res) => res.render('index'));

app.get('/login', (req, res) => res.render('login'));

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  // Logins fixos (em produção usar banco de dados)
  if(username === 'admin' && password === 'admin123') {
    req.session.user = { role: 'admin' };
    return res.redirect('/admin');
  }
  
  if(username === 'aluno' && password === 'aluno123') {
    req.session.user = { role: 'aluno' };
    return res.redirect('/aluno');
  }
  
  res.redirect('/login?error=1');
});

// Middleware de autenticação
const requireAuth = (role) => (req, res, next) => {
  if(req.session.user && req.session.user.role === role) return next();
  res.redirect('/login');
};


app.get('/aluno', requireAuth('aluno'), (req, res) => {
  // Consulta para pontuação total por turma
  const turmasQuery = `
    SELECT 
      t.id,
      t.turma || ' - ' || t.docente AS turma_docente,
      SUM(r.pontuacao * d.quantidade) AS total_pontos
    FROM doacoes d
    JOIN turmas t ON d.turma_id = t.id
    JOIN roupas r ON d.roupa_id = r.id
    GROUP BY t.id
    ORDER BY total_pontos DESC;
  `;

  // Consulta para itens doados por turma
  const itensQuery = `
    SELECT 
      t.id AS turma_id,
      r.tipo,
      r.pontuacao,
      SUM(d.quantidade) AS quantidade_total,
      SUM(r.pontuacao * d.quantidade) AS pontos_total
    FROM doacoes d
    JOIN turmas t ON d.turma_id = t.id
    JOIN roupas r ON d.roupa_id = r.id
    GROUP BY t.id, r.id
    ORDER BY t.id, r.tipo;
  `;

  db.serialize(() => {
    db.all(turmasQuery, (err, turmas) => {
      if (err) return console.error(err);
      
      db.all(itensQuery, (err, itens) => {
        if (err) return console.error(err);
        
        // Organizar itens por turma
        const itensPorTurma = {};
        itens.forEach(item => {
          if (!itensPorTurma[item.turma_id]) {
            itensPorTurma[item.turma_id] = [];
          }
          itensPorTurma[item.turma_id].push(item);
        });
        
        res.render('aluno', { turmas, itensPorTurma });
      });
    });
  });
});

// Painel Admin - Visualização de Doações
app.get('/admin/doacoes', requireAuth('admin'), (req, res) => {
  const query = `
    SELECT d.id, 
           t.turma || ' - ' || t.docente AS turma_docente,
           r.tipo, 
           r.pontuacao, 
           d.quantidade, 
           d.data,
           (r.pontuacao * d.quantidade) as pontos
    FROM doacoes d
    JOIN turmas t ON d.turma_id = t.id
    JOIN roupas r ON d.roupa_id = r.id
    ORDER BY d.data DESC
  `;
  
  db.all(query, (err, doacoes) => {
    res.render('admin_doacoes', { 
      doacoes,
      success: req.query.success 
    });
  });
});

// Painel Admin - Formulário de Registro
app.get('/admin', requireAuth('admin'), (req, res) => {
  db.parallelize(() => {
    // Combinar turma e docente na consulta
    db.all("SELECT id, turma || ' - ' || docente AS turma_info FROM turmas", (err, turmas) => {
      db.all("SELECT * FROM roupas", (err, roupas) => {
        res.render('admin', { turmas, roupas });
      });
    });
  });
});

// Painel Admin
app.get('/admin', requireAuth('admin'), (req, res) => {
  db.parallelize(() => {
    db.all("SELECT * FROM turmas", (err, turmas) => {
      db.all("SELECT * FROM roupas", (err, roupas) => {
        res.render('admin', { turmas, roupas });
      });
    });
  });
});

app.post('/doacao', requireAuth('admin'), (req, res) => {
  const { turma_id, roupa_id, quantidade, data } = req.body;
  
  db.run(
    `INSERT INTO doacoes (turma_id, roupa_id, quantidade, data)
     VALUES (?, ?, ?, ?)`,
    [turma_id, roupa_id, quantidade, data],
    (err) => {
      if(err) return console.error(err);
      res.redirect('/admin?success=1');
    }
  );
});
app.get('/admin/doacoes', requireAuth('admin'), (req, res) => {
  const query = `
    SELECT d.id, t.turma, r.tipo, r.pontuacao, d.quantidade, d.data,
           (r.pontuacao * d.quantidade) as pontos
    FROM doacoes d
    JOIN turmas t ON d.turma_id = t.id
    JOIN roupas r ON d.roupa_id = r.id
    ORDER BY d.data DESC
  `;
  
  db.all(query, (err, doacoes) => {
    res.render('admin_doacoes', { 
      doacoes,
      success: req.query.success 
    });
  });
});
app.post('/doacao', requireAuth('admin'), (req, res) => {
  const { turma_id, roupa_id, quantidade, data } = req.body;
  
  db.run(
    `INSERT INTO doacoes (turma_id, roupa_id, quantidade, data)
     VALUES (?, ?, ?, ?)`,
    [turma_id, roupa_id, quantidade, data],
    (err) => {
      if(err) return console.error(err);
      // Redireciona para a página de visualização de doações
      res.redirect('/admin/doacoes?success=1');
    }
  );
});
// Rota para o relatório de turmas
app.get('/admin/turmas', requireAuth('admin'), (req, res) => {
  // Consulta para pontuação total por turma
  const turmasQuery = `
    SELECT 
      t.id,
      t.turma || ' - ' || t.docente AS turma_docente,
      SUM(r.pontuacao * d.quantidade) AS total_pontos
    FROM doacoes d
    JOIN turmas t ON d.turma_id = t.id
    JOIN roupas r ON d.roupa_id = r.id
    GROUP BY t.id
    ORDER BY total_pontos DESC;
  `;

  // Consulta para itens doados por turma
  const itensQuery = `
    SELECT 
      t.id AS turma_id,
      r.tipo,
      r.pontuacao,
      SUM(d.quantidade) AS quantidade_total,
      SUM(r.pontuacao * d.quantidade) AS pontos_total
    FROM doacoes d
    JOIN turmas t ON d.turma_id = t.id
    JOIN roupas r ON d.roupa_id = r.id
    GROUP BY t.id, r.id
    ORDER BY t.id, r.tipo;
  `;

  db.serialize(() => {
    db.all(turmasQuery, (err, turmas) => {
      if (err) return console.error(err);
      
      db.all(itensQuery, (err, itens) => {
        if (err) return console.error(err);
        
        // Organizar itens por turma
        const itensPorTurma = {};
        itens.forEach(item => {
          if (!itensPorTurma[item.turma_id]) {
            itensPorTurma[item.turma_id] = [];
          }
          itensPorTurma[item.turma_id].push(item);
        });
        
        res.render('admin_turmas', { turmas, itensPorTurma });
      });
    });
  });
});


app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`Servidor rodando: http://localhost:${port}`);
});